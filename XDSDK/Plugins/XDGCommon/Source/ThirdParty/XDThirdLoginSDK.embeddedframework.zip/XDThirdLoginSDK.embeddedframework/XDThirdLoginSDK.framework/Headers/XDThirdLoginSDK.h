//
//  XDThirdLoginSDK.h
//  XDThirdLoginSDK
//
//  Created by Fattycat on 2022/5/26.
//

#import <Foundation/Foundation.h>

//! Project version number for XDThirdLoginSDK.
FOUNDATION_EXPORT double XDThirdLoginSDKVersionNumber;

//! Project version string for XDThirdLoginSDK.
FOUNDATION_EXPORT const unsigned char XDThirdLoginSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XDThirdLoginSDK/PublicHeader.h>


